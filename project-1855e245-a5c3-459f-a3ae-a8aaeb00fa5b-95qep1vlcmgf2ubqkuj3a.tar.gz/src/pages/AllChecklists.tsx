import React, { useState } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useChecklist } from '../contexts/ChecklistContext';
import { useUser } from '../contexts/UserContext';
import { SortableChecklistItem } from '../components/SortableChecklistItem';
import { PasswordProtection } from '../components/PasswordProtection';
import { AdminToolbar } from '../components/AdminToolbar';
import { CategoryManager } from '../components/CategoryManager';
import { UserSwitcher } from '../components/UserSwitcher';
import { Settings } from 'lucide-react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';

const AllChecklists = () => {
  const { items, reorderItems, clearAllCheckboxes, categories, addCategory, updateCategory, deleteCategory } = useChecklist();
  const { currentUser } = useUser();
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showCategoryManager, setShowCategoryManager] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  
  const userCategories = [...new Set(items.map(item => item.category))];

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      reorderItems(active.id as string, over.id as string);
    }
  };

  const handleAdminAccess = () => {
    setIsAdminMode(true);
    setShowPasswordModal(false);
  };

  const handleClearCheckboxes = () => {
    const completedCount = items.filter(item => item.completed).length;
    if (window.confirm(`Are you sure you want to clear all ${completedCount} checkboxes? The text will remain.`)) {
      clearAllCheckboxes();
    }
  };

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-gray-500">Please select a user to continue.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full w-full">
      <header className="flex items-center sticky top-0 z-10 gap-4 border-b bg-white px-6 py-4">
        <SidebarTrigger />
        <h1 className="text-2xl font-semibold flex-1">All Checklists</h1>
        <UserSwitcher />
        <button
          onClick={() => setShowPasswordModal(true)}
          className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          title="Admin Mode"
        >
          <Settings size={20} />
          Admin
        </button>
      </header>
      
      <main className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <AdminToolbar
            isAdminMode={isAdminMode}
            onExitAdmin={() => setIsAdminMode(false)}
            onClearCheckboxes={handleClearCheckboxes}
            onManageCategories={() => setShowCategoryManager(true)}
          />

          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            {userCategories.map(category => {
              const categoryItems = items.filter(item => item.category === category);
              return (
                <div key={category} className="bg-white rounded-lg shadow-sm border">
                  <div className="p-4 border-b bg-gray-50">
                    <h2 className="text-lg font-semibold text-gray-800">{category}</h2>
                    <p className="text-sm text-gray-600">
                      {categoryItems.filter(item => item.completed).length} of {categoryItems.length} completed
                    </p>
                  </div>
                  <div className="divide-y">
                    <SortableContext
                      items={categoryItems.map(item => item.id)}
                      strategy={verticalListSortingStrategy}
                    >
                      {categoryItems.map(item => (
                        <SortableChecklistItem
                          key={item.id}
                          item={item}
                          isAdminMode={isAdminMode}
                        />
                      ))}
                    </SortableContext>
                  </div>
                </div>
              );
            })}
          </DndContext>
          
          {userCategories.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No items yet. Start by adding some tasks!
            </div>
          )}
        </div>
      </main>

      <PasswordProtection
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onAuthenticated={handleAdminAccess}
      />

      <CategoryManager
        categories={categories}
        onAddCategory={addCategory}
        onUpdateCategory={updateCategory}
        onDeleteCategory={deleteCategory}
        isOpen={showCategoryManager}
        onClose={() => setShowCategoryManager(false)}
      />
    </div>
  );
};

export default AllChecklists;