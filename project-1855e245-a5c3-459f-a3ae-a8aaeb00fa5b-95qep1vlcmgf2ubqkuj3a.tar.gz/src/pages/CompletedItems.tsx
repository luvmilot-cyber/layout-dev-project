import React from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useChecklist } from '../contexts/ChecklistContext';
import { ChecklistItem } from '../components/ChecklistItem';
import { Trophy } from 'lucide-react';

const CompletedItems = () => {
  const { getCompletedItems } = useChecklist();
  const completedItems = getCompletedItems();

  return (
    <div className="flex flex-col h-full w-full">
      <header className="flex items-center sticky top-0 z-10 gap-4 border-b bg-white px-6 py-4">
        <SidebarTrigger />
        <div className="flex items-center gap-2">
          <Trophy className="text-yellow-500" size={24} />
          <h1 className="text-2xl font-semibold">Completed Tasks</h1>
        </div>
      </header>
      
      <main className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto">
          {completedItems.length > 0 ? (
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-4 border-b bg-green-50">
                <h2 className="text-lg font-semibold text-green-800">
                  🎉 {completedItems.length} tasks completed!
                </h2>
                <p className="text-sm text-green-600">Great job staying productive!</p>
              </div>
              <div className="divide-y">
                {completedItems.map(item => (
                  <ChecklistItem key={item.id} item={item} />
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Trophy className="mx-auto h-16 w-16 text-gray-300 mb-4" />
              <h2 className="text-xl font-semibold text-gray-700 mb-2">No completed tasks yet</h2>
              <p className="text-gray-600">Complete some tasks to see them here!</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default CompletedItems;