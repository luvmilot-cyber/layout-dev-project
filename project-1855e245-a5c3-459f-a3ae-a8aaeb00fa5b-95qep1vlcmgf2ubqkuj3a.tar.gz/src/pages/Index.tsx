import React, { useState } from 'react';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { useChecklist } from '../contexts/ChecklistContext';
import { useUser } from '../contexts/UserContext';
import { SortableChecklistItem } from '../components/SortableChecklistItem';
import { AddItemForm } from '../components/AddItemForm';
import { PasswordProtection } from '../components/PasswordProtection';
import { AdminToolbar } from '../components/AdminToolbar';
import { CategoryManager } from '../components/CategoryManager';
import { UserSwitcher } from '../components/UserSwitcher';
import { format } from 'date-fns';
import { Settings } from 'lucide-react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';

const Index = () => {
  const { getTodaysItems, reorderItems, clearAllCheckboxes, categories, addCategory, updateCategory, deleteCategory } = useChecklist();
  const { currentUser } = useUser();
  const todaysItems = getTodaysItems();
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showCategoryManager, setShowCategoryManager] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const filteredItems = todaysItems.filter(item => {
    if (filter === 'pending') return !item.completed;
    if (filter === 'completed') return item.completed;
    return true;
  });

  const completedCount = todaysItems.filter(item => item.completed).length;
  const totalCount = todaysItems.length;

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      reorderItems(active.id as string, over.id as string);
    }
  };

  const handleAdminAccess = () => {
    setIsAdminMode(true);
    setShowPasswordModal(false);
  };

  const handleClearCheckboxes = () => {
    if (window.confirm(`Are you sure you want to clear all ${completedCount} checkboxes? The text will remain.`)) {
      clearAllCheckboxes();
    }
  };

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-gray-500">Please select a user to continue.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full w-full">
      <header className="flex items-center sticky top-0 z-10 gap-4 border-b bg-white px-6 py-4">
        <SidebarTrigger />
        <div className="flex-1">
          <h1 className="text-2xl font-semibold">Today's Tasks</h1>
          <p className="text-sm text-muted-foreground">
            {format(new Date(), 'EEEE, MMMM d, yyyy')} • {completedCount} of {totalCount} completed
          </p>
        </div>
        <UserSwitcher />
        <button
          onClick={() => setShowPasswordModal(true)}
          className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          title="Admin Mode"
        >
          <Settings size={20} />
          Admin
        </button>
      </header>
      
      <main className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <AddItemForm />
          
          <AdminToolbar
            isAdminMode={isAdminMode}
            onExitAdmin={() => setIsAdminMode(false)}
            onClearCheckboxes={handleClearCheckboxes}
            onManageCategories={() => setShowCategoryManager(true)}
          />
          
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-4 border-b">
              <div className="flex gap-2">
                {(['all', 'pending', 'completed'] as const).map((filterType) => (
                  <button
                    key={filterType}
                    onClick={() => setFilter(filterType)}
                    className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                      filter === filterType
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                    }`}
                  >
                    {filterType.charAt(0).toUpperCase() + filterType.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="divide-y">
              {filteredItems.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  {filter === 'all' && "No tasks for today. Add one above!"}
                  {filter === 'pending' && "No pending tasks. Great job!"}
                  {filter === 'completed' && "No completed tasks yet."}
                </div>
              ) : (
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext
                    items={filteredItems.map(item => item.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    {filteredItems.map((item) => (
                      <SortableChecklistItem
                        key={item.id}
                        item={item}
                        isAdminMode={isAdminMode}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
              )}
            </div>
          </div>
        </div>
      </main>

      <PasswordProtection
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onAuthenticated={handleAdminAccess}
      />

      <CategoryManager
        categories={categories}
        onAddCategory={addCategory}
        onUpdateCategory={updateCategory}
        onDeleteCategory={deleteCategory}
        isOpen={showCategoryManager}
        onClose={() => setShowCategoryManager(false)}
      />
    </div>
  );
};

export default Index;