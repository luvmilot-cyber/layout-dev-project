import React, { createContext, useState, useContext } from 'react';
import { useUser } from './UserContext';

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  createdAt: Date;
  completedAt?: Date;
  category: string;
  order: number;
  userId: string;
}

interface ChecklistContextType {
  items: ChecklistItem[];
  categories: string[];
  addItem: (text: string, category?: string) => void;
  toggleItem: (id: string) => void;
  deleteItem: (id: string) => void;
  updateItem: (id: string, text: string) => void;
  reorderItems: (activeId: string, overId: string) => void;
  clearAllCheckboxes: () => void;
  addCategory: (category: string) => void;
  updateCategory: (oldCategory: string, newCategory: string) => void;
  deleteCategory: (category: string) => void;
  getItemsByCategory: (category: string) => ChecklistItem[];
  getTodaysItems: () => ChecklistItem[];
  getCompletedItems: () => ChecklistItem[];
  getCurrentUserItems: () => ChecklistItem[];
}

const ChecklistContext = createContext<ChecklistContextType | null>(null);

const defaultCategories = ['General', 'Work', 'Personal', 'Health', 'Shopping', 'Study'];

export const ChecklistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useUser();
  const [allItems, setAllItems] = useState<ChecklistItem[]>([
    {
      id: '1',
      text: 'Review project requirements',
      completed: false,
      createdAt: new Date(),
      category: 'Work',
      order: 0,
      userId: '1'
    },
    {
      id: '2',
      text: 'Buy groceries',
      completed: true,
      createdAt: new Date(Date.now() - 86400000),
      completedAt: new Date(Date.now() - 3600000),
      category: 'Personal',
      order: 1,
      userId: '1'
    },
    {
      id: '3',
      text: 'Call dentist for appointment',
      completed: false,
      createdAt: new Date(),
      category: 'Health',
      order: 2,
      userId: '2'
    },
    {
      id: '4',
      text: 'Prepare presentation slides',
      completed: false,
      createdAt: new Date(),
      category: 'Work',
      order: 3,
      userId: '2'
    }
  ]);
  const [categories, setCategories] = useState<string[]>(defaultCategories);

  // Filter items for current user
  const items = allItems.filter(item => item.userId === currentUser?.id);

  const addItem = (text: string, category: string = 'General') => {
    if (!currentUser) return;
    
    const userItems = allItems.filter(item => item.userId === currentUser.id);
    const maxOrder = Math.max(...userItems.map(item => item.order), -1);
    const newItem: ChecklistItem = {
      id: Date.now().toString(),
      text,
      completed: false,
      createdAt: new Date(),
      category,
      order: maxOrder + 1,
      userId: currentUser.id
    };
    setAllItems([...allItems, newItem]);
  };

  const toggleItem = (id: string) => {
    setAllItems(allItems.map(item => 
      item.id === id 
        ? { 
            ...item, 
            completed: !item.completed,
            completedAt: !item.completed ? new Date() : undefined
          }
        : item
    ));
  };

  const deleteItem = (id: string) => {
    setAllItems(allItems.filter(item => item.id !== id));
  };

  const updateItem = (id: string, text: string) => {
    setAllItems(allItems.map(item => 
      item.id === id ? { ...item, text } : item
    ));
  };

  const reorderItems = (activeId: string, overId: string) => {
    if (!currentUser) return;
    
    const userItems = allItems.filter(item => item.userId === currentUser.id);
    const activeIndex = userItems.findIndex(item => item.id === activeId);
    const overIndex = userItems.findIndex(item => item.id === overId);
    
    if (activeIndex !== overIndex) {
      const newUserItems = [...userItems];
      const [reorderedItem] = newUserItems.splice(activeIndex, 1);
      newUserItems.splice(overIndex, 0, reorderedItem);
      
      // Update order values for user items
      const updatedUserItems = newUserItems.map((item, index) => ({
        ...item,
        order: index
      }));
      
      // Replace user items in all items
      const otherItems = allItems.filter(item => item.userId !== currentUser.id);
      setAllItems([...otherItems, ...updatedUserItems]);
    }
  };

  const clearAllCheckboxes = () => {
    if (!currentUser) return;
    
    setAllItems(allItems.map(item => 
      item.userId === currentUser.id
        ? { ...item, completed: false, completedAt: undefined }
        : item
    ));
  };

  const addCategory = (category: string) => {
    if (!categories.includes(category)) {
      setCategories([...categories, category]);
    }
  };

  const updateCategory = (oldCategory: string, newCategory: string) => {
    setCategories(categories.map(cat => cat === oldCategory ? newCategory : cat));
    setAllItems(allItems.map(item => 
      item.category === oldCategory ? { ...item, category: newCategory } : item
    ));
  };

  const deleteCategory = (category: string) => {
    if (category === 'General') return; // Don't allow deleting General category
    
    setCategories(categories.filter(cat => cat !== category));
    setAllItems(allItems.map(item => 
      item.category === category ? { ...item, category: 'General' } : item
    ));
  };

  const getItemsByCategory = (category: string) => {
    return items.filter(item => item.category === category).sort((a, b) => a.order - b.order);
  };

  const getTodaysItems = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return items.filter(item => {
      const itemDate = new Date(item.createdAt);
      itemDate.setHours(0, 0, 0, 0);
      return itemDate.getTime() === today.getTime();
    }).sort((a, b) => a.order - b.order);
  };

  const getCompletedItems = () => {
    return items.filter(item => item.completed).sort((a, b) => a.order - b.order);
  };

  const getCurrentUserItems = () => {
    return items.sort((a, b) => a.order - b.order);
  };

  return (
    <ChecklistContext.Provider value={{
      items: items.sort((a, b) => a.order - b.order),
      categories,
      addItem,
      toggleItem,
      deleteItem,
      updateItem,
      reorderItems,
      clearAllCheckboxes,
      addCategory,
      updateCategory,
      deleteCategory,
      getItemsByCategory,
      getTodaysItems,
      getCompletedItems,
      getCurrentUserItems
    }}>
      {children}
    </ChecklistContext.Provider>
  );
};

export const useChecklist = () => {
  const context = useContext(ChecklistContext);
  if (!context) throw new Error('useChecklist must be used within ChecklistProvider');
  return context;
};