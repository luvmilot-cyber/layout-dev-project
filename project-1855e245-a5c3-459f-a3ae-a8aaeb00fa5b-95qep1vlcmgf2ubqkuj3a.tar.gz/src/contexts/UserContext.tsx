import React, { createContext, useState, useContext } from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

interface UserContextType {
  currentUser: User | null;
  users: User[];
  switchUser: (userId: string) => void;
  addUser: (name: string, email: string) => void;
  deleteUser: (userId: string) => void;
}

const UserContext = createContext<UserContextType | null>(null);

const defaultUsers: User[] = [
  { id: '1', name: 'John Doe', email: 'john@example.com', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face' },
  { id: '2', name: 'Jane Smith', email: 'jane@example.com', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face' },
  { id: '3', name: 'Mike Johnson', email: 'mike@example.com', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face' },
];

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(defaultUsers[0]);
  const [users, setUsers] = useState<User[]>(defaultUsers);

  const switchUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setCurrentUser(user);
    }
  };

  const addUser = (name: string, email: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face`
    };
    setUsers([...users, newUser]);
  };

  const deleteUser = (userId: string) => {
    if (users.length > 1) {
      setUsers(users.filter(u => u.id !== userId));
      if (currentUser?.id === userId) {
        setCurrentUser(users.find(u => u.id !== userId) || null);
      }
    }
  };

  return (
    <UserContext.Provider value={{
      currentUser,
      users,
      switchUser,
      addUser,
      deleteUser
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) throw new Error('useUser must be used within UserProvider');
  return context;
};