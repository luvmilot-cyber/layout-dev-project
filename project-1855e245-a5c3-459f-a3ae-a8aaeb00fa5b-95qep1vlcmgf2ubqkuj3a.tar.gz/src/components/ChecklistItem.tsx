import React, { useState } from 'react';
import { format } from 'date-fns';
import { Check, Clock, Edit2, Trash2, Save, X } from 'lucide-react';
import { useChecklist, ChecklistItem as ChecklistItemType } from '../contexts/ChecklistContext';

interface ChecklistItemProps {
  item: ChecklistItemType;
}

export const ChecklistItem: React.FC<ChecklistItemProps> = ({ item }) => {
  const { toggleItem, deleteItem, updateItem } = useChecklist();
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(item.text);

  const handleSave = () => {
    if (editText.trim()) {
      updateItem(item.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(item.text);
    setIsEditing(false);
  };

  return (
    <div className={`p-4 transition-all duration-200 ${
      item.completed ? 'bg-gray-50' : 'bg-white hover:bg-gray-50'
    }`}>
      <div className="flex items-start gap-3">
        <button
          onClick={() => toggleItem(item.id)}
          className={`mt-1 w-5 h-5 rounded border-2 flex items-center justify-center transition-all duration-200 ${
            item.completed
              ? 'bg-green-500 border-green-500 text-white'
              : 'border-gray-300 hover:border-green-500'
          }`}
        >
          {item.completed && <Check size={14} />}
        </button>
        
        <div className="flex-1 min-w-0">
          {isEditing ? (
            <div className="space-y-2">
              <input
                type="text"
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSave();
                  if (e.key === 'Escape') handleCancel();
                }}
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  onClick={handleSave}
                  className="text-green-600 hover:text-green-700"
                >
                  <Save size={16} />
                </button>
                <button
                  onClick={handleCancel}
                  className="text-gray-600 hover:text-gray-700"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ) : (
            <>
              <p className={`text-gray-800 ${item.completed ? 'line-through text-gray-500' : ''}`}>
                {item.text}
              </p>
              
              <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                <div className="flex items-center gap-1">
                  <Clock size={12} />
                  <span>Created: {format(item.createdAt, 'MMM d, h:mm a')}</span>
                </div>
                
                {item.completedAt && (
                  <div className="flex items-center gap-1 text-green-600">
                    <Check size={12} />
                    <span>Completed: {format(item.completedAt, 'MMM d, h:mm a')}</span>
                  </div>
                )}
                
                <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                  {item.category}
                </span>
              </div>
            </>
          )}
        </div>
        
        {!isEditing && (
          <div className="flex gap-1">
            <button
              onClick={() => setIsEditing(true)}
              className="text-gray-400 hover:text-blue-600 transition-colors"
            >
              <Edit2 size={16} />
            </button>
            <button
              onClick={() => deleteItem(item.id)}
              className="text-gray-400 hover:text-red-600 transition-colors"
            >
              <Trash2 size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};