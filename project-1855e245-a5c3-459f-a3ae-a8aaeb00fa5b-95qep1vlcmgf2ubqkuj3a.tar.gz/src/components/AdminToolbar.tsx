import React from 'react';
import { RotateCcw, Lock, Tag } from 'lucide-react';
import { useChecklist } from '../contexts/ChecklistContext';

interface AdminToolbarProps {
  isAdminMode: boolean;
  onExitAdmin: () => void;
  onClearCheckboxes: () => void;
  onManageCategories: () => void;
}

export const AdminToolbar: React.FC<AdminToolbarProps> = ({
  isAdminMode,
  onExitAdmin,
  onClearCheckboxes,
  onManageCategories
}) => {
  const { items } = useChecklist();
  const completedCount = items.filter(item => item.completed).length;

  if (!isAdminMode) return null;

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Lock className="text-blue-600" size={20} />
          <span className="font-medium text-blue-800">Admin Mode Active</span>
          <span className="text-sm text-blue-600">
            • Drag items to reorder • Manage categories • Clear checkboxes
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={onManageCategories}
            className="flex items-center gap-2 px-3 py-1 bg-purple-500 text-white rounded-md hover:bg-purple-600 transition-colors text-sm"
          >
            <Tag size={16} />
            Categories
          </button>
          
          <button
            onClick={onClearCheckboxes}
            disabled={completedCount === 0}
            className="flex items-center gap-2 px-3 py-1 bg-orange-500 text-white rounded-md hover:bg-orange-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
          >
            <RotateCcw size={16} />
            Clear {completedCount} Checkboxes
          </button>
          
          <button
            onClick={onExitAdmin}
            className="px-3 py-1 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition-colors text-sm"
          >
            Exit Admin
          </button>
        </div>
      </div>
    </div>
  );
};