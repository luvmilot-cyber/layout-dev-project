import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical } from 'lucide-react';
import { ChecklistItem } from './ChecklistItem';
import { ChecklistItem as ChecklistItemType } from '../contexts/ChecklistContext';

interface SortableChecklistItemProps {
  item: ChecklistItemType;
  isAdminMode: boolean;
}

export const SortableChecklistItem: React.FC<SortableChecklistItemProps> = ({
  item,
  isAdminMode
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} className="relative">
      {isAdminMode && (
        <div
          {...attributes}
          {...listeners}
          className="absolute left-2 top-1/2 transform -translate-y-1/2 cursor-grab active:cursor-grabbing z-10 p-1 hover:bg-gray-100 rounded"
        >
          <GripVertical size={16} className="text-gray-400" />
        </div>
      )}
      <div className={isAdminMode ? 'ml-8' : ''}>
        <ChecklistItem item={item} />
      </div>
    </div>
  );
};